2048 Game - Standalone Executable

This is a standalone version of the 2048 puzzle game.

How to run:
1. Double-click on 2048_Game.exe
2. Use arrow keys to move tiles
3. Press U to undo, R to redo
4. Press ESC to restart

Enjoy the game!
